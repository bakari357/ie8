<?php

return array(
    'proxyhost'     => '',
    'proxyport' => '',
'proxyusername' => '',
'proxypassword' => ''
);
