// app/lib/Acme/Product/Anvil/AnvilInterface.php
<?php namespace Acme\Product\Anvil;

interface AnvilInterface {

    public function drop();

}


