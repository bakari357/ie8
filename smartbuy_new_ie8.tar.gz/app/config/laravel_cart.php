<?php
	return array(
	 'tax_shipping' => false,
	 'allow_os_purchase'=> true
	);
 
 

