<?php

return array(

	'path'    => app_path() . '/themes',

	'default' => 'default'

);
