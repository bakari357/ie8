<?php

return array(
    	      'staging'=> array(
				  'c_code'=>'REWARDS360',
				  'm_code'=>'REWARDS360',
				  'url'=>'https://flexatsup.hdfcbank.com/netbanking/merchant?',
				  'vurl'=>'https://flexatsup.hdfcbank.com/netbanking/epi?',
				  'durl'=>'http://202.140.38.73/smartbuy_new/public/getResponse',
				  'currency'=>'INR',
				  'ckey'=>123456
				 ),


		'production'=>array(
					'c_code'=>'REWARDS360',
					'm_code'=>'REWARDS360',
					'vurl'=>'https://netbanking.hdfcbank.com/netbanking/epi?',
					'url'=>'https://netbanking.hdfcbank.com/netbanking/merchant?',
					'durl'=>'http://202.140.38.73/smartbuy_new/public/getResponse',
					'currency'=>'INR',
					'ckey'=>912345
			           ),


		'active'=>'staging'
	     );







