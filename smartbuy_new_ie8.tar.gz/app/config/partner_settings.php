<?php
return array(
    		 'alias'=>array(
					'movie1' => 'Cinepolis',
			   		'movie2' => 'Funcinemas',
					'hotels1'=>'Expedia',
					'hotels2'=>'clear trip Hotels',
					'flights1'=>'goibibo',
					'flights2'=>'clear trip Flights',
					'music'=>'Hungama',
					'recharge'=>'Billdesk'
				),

				'clear_trip_booking'=>array('TEST','TEST','sharathnath224@gmail.com','9739660088')

				);







?>
