<?php

return array(
    	      'staging'=> array(
				  'tid'=>'9000898',
				  'mid'=>'13398',
				  'password'=>'password1',
				  'url'=>'https://securepgtest.fssnet.co.in/pgway/servlet/PaymentInitHTTPServlet',
				  'ip'=>array('221.134.101.175','221.134.101.187','221.134.101.169'),
				 ),


		'production'=>array(
					'tid'=>'70009504',
					'mid'=>'5181',
					'password'=>'70009504',
					'url'=>'https://securepg.fssnet.co.in/pgway/servlet/PaymentInitHTTPServlet',
					'ip'=>array('221.134.101.175','221.134.101.187','221.134.101.169'),	
			           ),


		'active'=>'staging'
	     );







