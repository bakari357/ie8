<div class="col-md-4">
<div class="margtop15"><span class="dark">Contact Name:</span><span class="red">*</span></div>
</div>

<div class="col-md-3">
<span class="size12">First Name</span>
<input type="text" name="first_name" id="firstName"class="form-control " placeholder=""></div>
<div class="col-md-3">
<span class="size12">Last Name</span>
<input type="text" name="last_name" id="lastName" class="form-control " placeholder="">
</div>
<div class="clearfix"></div>

<br/>




<div class="col-md-4">
<div class="margtop15"><span class="dark">Email Address:</span><span class="red">*</span></div>
</div>
<div class="col-md-6">
<input type="text" name="s_email" class="form-control margtop10" placeholder="" style="width: 310px;"><br>
</div>
<div class="col-md-4">
<div class="margtop15"><span class="dark">Preferred Phone Number:</span><span class="red">*</span></div>
</div>
<div class="col-md-6">
<input style="width:16%;position: absolute;" type="text" readonly value="+91" class="form-control"/><input type="text" name = "mobile" class="form-control" placeholder="" style="
margin-left: 17%;width:84%;">
</div>
<div class="clearfix"></div><br>


<div class="col-md-4">
<div class="margtop15"><span class="dark">Address Details:</span><span class="red">*</span></div>
</div>

<div class="col-md-3">
<span class="size12">Country</span>
<input type="text" name="country" id="country"class="form-control " placeholder=""></div>

<div class="col-md-3">
<span class="size12">State</span>
<input type="text" name="state" id="state" class="form-control " placeholder="">
</div>

<div class="col-md-4">
<div class="margtop15"></div>
</div>

<div class="col-md-3">
<span class="size12">City</span>
<input type="text" name="city" id="city"class="form-control " placeholder=""></div>

<div class="col-md-3">
<span class="size12">Pincode</span>
<input type="text" name="pincode" id="pincode" class="form-control " placeholder="">
</div>

<div class="clearfix"></div><br>
<div class="col-md-4">

</div>
<div class="col-md-6">
    <span class="size12">Address</span>
<textarea name="address" id="address" class="form-control margtop10" placeholder=""> </textarea>
</div>




<div class="clearfix"></div>
<div class="col-md-4">
<div class="margtop15"><span class="dark"></span></div>
</div>

<div class="clearfix"></div>

<div class="clearfix"></div><br><br>
( All email notifications will be sent to the above address).<br/><br/> 

<span class='size16px bold dark left'>Review and book your trip</span>
<div class='roundstep right'>3</div>
<div class='clearfix'></div><div class='line4'></div>
					
					
			
					
				
