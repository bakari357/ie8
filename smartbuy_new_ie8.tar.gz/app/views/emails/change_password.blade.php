<DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2></h2>

		<div>
		<?php echo $message="<div style='font-family:Trebuchet MS, Times, arial; font-size:12px;color:#000033;'>Dear User, 
              <p>As per your request, the password has been changed successfully. <p/>
                 <p> In case you have any queries, please feel free to contact us at abc@rewards.com. </p> 
<br/>
		
                <p>Thanks and Regards ,<br />SmartBuy Team.<p/>
                   <p> **This e-mail is for information only. Please do not respond to it. ** </p></div>";?>


		 
		</div>
	</body>
</html>
