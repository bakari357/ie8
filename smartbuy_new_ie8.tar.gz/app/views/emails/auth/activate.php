
<?php
/**
 * @var User $user
 */
?>


<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2></h2>

		<div>
		<?php echo $message="<div style='font-family:Trebuchet MS, Times, arial; font-size:12px;color:#000033;'>Hi '". $mail['password']."',<br />Password : '". $mail['password']."'<br/>Please find the below your Account Details<br /><br/><br />
		
		
		
		   
		<br /><br /><br />Regards ,<br /><br />REWARD360<br />Address: 2/2 Lavelle Road Bangalore-560001.</div>";?>
		
		</div>
	</body>
</html>
