<?php echo $code; ?> 	
