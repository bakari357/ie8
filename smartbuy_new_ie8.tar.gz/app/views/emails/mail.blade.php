<DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2></h2>

		<div>
		<?php echo $message="<div style='font-family:Trebuchet MS, Times, arial; font-size:12px;color:#000033;'>Dear User, 
              <p>You or someone else recently made a 'Forgot Password' request associated with this email id, at SmartBuy. <p/>
                 <p> Your password is: <font color='blue'>". $code['password']." </font> (Password is case-sensitive) </p> 

		<p> Please go to www.smartbuy.hdfcbank.com to and login to your account.</p>
<br />
                <p>Thanks and Regards ,<br />SmartBuy Team.<p/>
                   <p> **This e-mail is for information only. Please do not respond to it. ** </p></div>";?>


		 
		</div>
	</body>
</html>
