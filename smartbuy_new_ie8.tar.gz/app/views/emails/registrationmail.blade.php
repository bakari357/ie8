<DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2></h2>

		<div>
		<?php echo $message="<div style='font-family:Trebuchet MS, Times, arial; font-size:12px;color:#000033;'>Dear User,
                 <p>Welcome! You are now a registered member of SmartBuy.  <p>As a member, you will be able to view a history of your purchases.<p/>
                  <p>In case you have any queries, please feel free to contact us at 080-000-0000 or drop us an e-mail at abc@rewards.com and we will assist you promptly.</p>
                  <p> We are glad to welcome you on board.</p> <br />
	
		<p>Thanks and Regards ,<br />SmartBuy Team.<p/>
                   <p> **This e-mail is for information only. Please do not respond to it. **</p></div>";?>
		
		</div>
	</body>
</html>
