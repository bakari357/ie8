<?php
$checkout='';
return array(
		'cleartrip'=>array(
				    'checkout'=>'<b> <span class="attention">Attention!</span> <span class="attention_sub">Please read important flight ticket information!</span>	</b><br/><br/>
                                <p class="size12">• This ticket is booked though our partner Cleartrip.</p>
                                <p  class="size12">
                                • For any query and/or activity related to the service and/or modification and cancellation, please contact Cleartrip at agencysupport@cleartrip.com, 1860 233 5000 and +91 22 40554955. Refund on flight ticket will be as per the airline rules.
                                </p>
                                <p  class="size12">
                                • HDFC Bank SmartBuy is not responsible for any cancellations that occur at the partner side.
                                </p>
                                <p class="size12">• All bookings, modifications and cancellations are subject to Partner terms and conditions.</p>
                                <p class="size12">• HDFC Bank is acting merely as a facilitator and the services and/or goods purchased on SmartBuy are provided by our partners/ merchants. And HDFC bank is not responsible for any fees, charges and/ or taxes levied by the partners/ merchants.</p>
                                       '
				   ),
		'goibibo'=>array(
				 'checkout'=>'<b><span class="attention">Attention!</span> <span class="attention_sub">Please read important flight ticket information!</span>	</b><br/><br/>
                                <p class="size12">• This ticket is booked though our partner Goibibo.</p>
                                <p  class="size12">
                                • For any query and/or activity related to the service and/or modification and cancellation, please contact Goibibo at smartbuy@goibibo.com and 0124-619103. Refund on flight ticket will be as per the airline rules.
                                </p>
                                <p  class="size12">
                                • HDFC Bank SmartBuy is not responsible for any cancellations that occur at the partner.
                                </p>
                                <p class="size12">• All bookings, modifications and cancellations are subject to Partner terms and conditions.</p>
                                <p class="size12">• HDFC Bank is acting merely as a facilitator and the services and/or goods purchased on SmartBuy are provided by our partners/ merchants. And HDFC bank is not responsible for any fees, charges and/ or taxes levied by the partners/ merchants.</p>'
                                
				),
				
				'recharge'=>array(
					'checkout'=>"<span class='attention'>Attention!</span> <span class='attention_sub'>Please read important recharge / bill payment information!</span> <br/> <br/>
					 <p class='size12' style='font-size: 13px'>• This recharge / bill payment is processed through our partner Billdesk.</p>
					 <p class='size12' style='font-size: 13px'>• For any query related to payment status, please contact us at support@smartbuy.com and &nbsp;1860 425 3322.</p>
					  <p class='size12' style='font-size: 13px'>• Onus to provide correct payment information lies with the customer.</p>
					 
					<p class='size12' style='font-size: 13px'>• HDFC Bank SmartBuy is not responsible for any failures  &nbsp; / delays that occur at the partner side.</p>
					 
					<p class='size12' style='font-size: 13px'>• Bills paid/ recharges done through the portal cannot be &nbsp;&nbsp;cancelled or modified.</p>
                                        <p class='size12' style='font-size: 13px'>• HDFC Bank is acting merely as an facilitator and that &nbsp;the severices and/or goods are provided or sold by the &nbsp; merchants.</p>
					"
				   )

		

		);



?>
















