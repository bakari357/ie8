<?php

    phpinfo();
    ?>
